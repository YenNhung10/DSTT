<?php
$cn = new mysqli("localhost", "root", "", "coffeeshop");
if ($cn->connect_error) {
    die("Lỗi kết nối database: " . $cn->connect_error);
}

// Hàm tạo mã đơn hàng
function createOrderCode() {
    return "ODR" . rand(1000, 9999);
}

// Nếu người dùng submit form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ten = $_POST['ten'];
    $sdt = $_POST['sdt'];
    $diachi = $_POST['diachi'];
    $payment = $_POST['payment'];
    $order_code = createOrderCode();
    $total = 0; // Giả sử bạn tính từ giỏ hàng, tạm để 0

    // Lưu đơn hàng vào bảng orders
    $stmt = $cn->prepare("INSERT INTO orders (order_code, customer_name, phone, address, payment_method, total, status, order_date) VALUES (?, ?, ?, ?, ?, ?, 'Chưa xử lý', NOW())");
    $stmt->bind_param("sssssi", $order_code, $ten, $sdt, $diachi, $payment, $total);
    $stmt->execute();

    $order_id = $stmt->insert_id; // ID vừa insert

    // Nếu có giỏ hàng, bạn có thể lưu vào bảng order_items ở đây
    // $stmt_items = $cn->prepare("INSERT INTO order_items (...) VALUES (...)");

    $stmt->close();

    $success = true;
}
?>

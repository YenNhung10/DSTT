<?php
// Kết nối database
$cn = new mysqli("localhost", "root", "", "coffeeshop");
if ($cn->connect_error) {
    die("Lỗi kết nối: " . $cn->connect_error);
}

// Hàm sinh mã đơn hàng
function createOrderCode() {
    return "ODR" . rand(1000, 9999);
}

// Khi thêm đơn hàng
if (isset($_POST['submit_order'])) {
    $orderCode = createOrderCode(); // gọi hàm để tạo mã
    $total = $_POST['total'];
    $status = 'pending';

    $sql = "INSERT INTO orders (order_code, total, status) VALUES ('$orderCode', '$total', '$status')";
    $cn->query($sql);
    echo "Đơn hàng đã tạo: $orderCode";
}
?>


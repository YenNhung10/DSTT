<?php
$cn = new mysqli("localhost", "root", "", "coffeeshop");
if ($cn->connect_error) {
    die("Lỗi kết nối database: " . $cn->connect_error);
}

function createOrderCode() {
    return "ODR" . rand(1000, 9999);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ten = $_POST['ten'];
    $sdt = $_POST['sdt'];
    $diachi = $_POST['diachi'];
    $payment = $_POST['payment'];
    $order_code = createOrderCode();
    $total = 0; // tính từ giỏ hàng nếu có

    $stmt = $cn->prepare("INSERT INTO orders (order_code, customer_name, phone, address, payment_method, total, status, order_date) VALUES (?, ?, ?, ?, ?, ?, 'Chưa xử lý', NOW())");
    $stmt->bind_param("sssssi", $order_code, $ten, $sdt, $diachi, $payment, $total);
    $stmt->execute();

    $stmt->close();
    $success = true;
}
?>

<body>
    <h2>THÔNG TIN NGƯỜI NHẬN</h2>

    <!-- FORM ĐẶT HÀNG -->
    <form method="POST" action="checkout.php">
        <div class="section">
            <label>Tên người nhận:</label>
            <input type="text" name="ten" required>

            <label>Số điện thoại:</label>
            <input type="text" name="sdt" required>

            <label>Địa chỉ:</label>
            <input type="text" name="diachi" required>
        </div>

        <div class="section">
            <label>Phương thức thanh toán:</label>
            <input type="radio" name="payment" value="COD" required> Thanh toán khi nhận hàng <br>
            <input type="radio" name="payment" value="MOMO"> Ví điện tử MOMO <br>
            <input type="radio" name="payment" value="VNPAY"> Thanh toán qua VNPAY <br>
            <input type="radio" name="payment" value="BANK"> Thẻ ngân hàng <br>
        </div>

        <button type="submit" class="btn">MUA HÀNG</button>
    </form>

</body>

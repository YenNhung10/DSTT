// Smooth scrolling for anchor links
document.querySelectorAll('a[href="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Product hover animations
const productCards = document.querySelectorAll('.product-card');
productCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-15px)';
    });
    card.addEventLisener('mouseleave', function(){
        this.style.transform = 'translateY(0)';
    });
});


// Hiển thị form khi nhấn Sign In
document.getElementById('sign-in-link').addEventListener('click', function() {
    document.getElementById('login-form').style.display = 'block';
});

// Đóng form khi nhấn Close
document.getElementById('close-login').addEventListener('click', function() {
    document.getElementById('login-form').style.display = 'none';
});

// Xử lý login
const loginForm = document.getElementById('loginForm');

loginForm.addEventListener('submit', function(e) {
    e.preventDefault(); // Ngăn reload trang

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if(email === "admin@coffee.com" && password === "123456"){
        // Chuyển tới trang admin
        window.location.href = "admin.html";
    } else {
        alert("Email hoặc mật khẩu không đúng!");
    }
});

const track = document.querySelector('.slider-track');
const prev = document.querySelector('.prev');
const next = document.querySelector('.next');

let position = 0;
const slideWidth = 270; // 250px + 20px gap

next.addEventListener('click', () => {
    position -= slideWidth;
    if (Math.abs(position) >= track.scrollWidth - track.clientWidth) {
        position = -(track.scrollWidth - track.clientWidth);
    }
    track.style.transform = `translateX(${position}px)`;
});

prev.addEventListener('click', () => {
    position += slideWidth;
    if (position > 0) position = 0;
    track.style.transform = `translateX(${position}px)`;
});


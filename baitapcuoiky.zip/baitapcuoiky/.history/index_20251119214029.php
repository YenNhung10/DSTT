<?php
session_start();
$conn = new mysqli("localhost", "root", "", "coffee_shop");

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM orders WHERE user_id = $user_id ORDER BY order_date DESC");
?>

<h1>Purchase History</h1>
<table border="1">
    <tr>
        <th>Product</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Date</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['product_name'] ?></td>
        <td>$<?= $row['price'] ?></td>
        <td><?= $row['quantity'] ?></td>
        <td><?= $row['order_date'] ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<?php
$conn = new mysqli("localhost", "root", "", "your_database");

$total = 120000;
$status = "Processing";

// 1. Tạo dòng đơn hàng trống trước
$sql = "INSERT INTO orders (total, status) VALUES ('$total', '$status')";
$conn->query($sql);

// 2. Lấy ID tự tăng vừa tạo
$last_id = $conn->insert_id;

// 3. Tạo mã đơn: ODR + ID
$order_code = "ODR" . str_pad($last_id, 5, "0", STR_PAD_LEFT);

// 4. Cập nhật mã đơn hàng vào bảng
$conn->query("UPDATE orders SET order_code='$order_code' WHERE id=$last_id");

echo "Mã đơn hàng của bạn là: $order_code";
</php>


$cn = new mysqli("localhost", "root", "", "coffeeshop");

$orderCode = createOrderCode();
$date = date("Y-m-d H:i:s");
$status = "Pending";
$total = 129500;

// Insert vào bảng orders
$sql = "INSERT INTO orders (order_code, order_date, status, total)
        VALUES ('$orderCode', '$date', '$status', $total)";
$cn->query($sql);

// Lấy ID đơn hàng vừa tạo
$orderID = $cn->insert_id;

// Insert items
$items = [
    ["Cà phê rang xay 500g", 1],
    ["Ly sứ cao cấp", 2]
];

foreach ($items as $item) {
    $name = $item[0];
    $qty = $item[1];
    $cn->query("INSERT INTO order_items (order_id, item_name, qty)
                VALUES ($orderID, '$name', $qty)");
}

echo "Đã tạo đơn hàng: $orderCode";

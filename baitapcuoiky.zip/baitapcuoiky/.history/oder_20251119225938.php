<?php
$cn = new mysqli("localhost", "root", "", "coffeeshop");

if ($cn->connect_error) {
    die("Lỗi kết nối database: " . $cn->connect_error);
}

$result = $cn->query("SELECT order_code, total, status FROM orders");

echo "<h2>Danh sách đơn hàng</h2>";

while ($row = $result->fetch_assoc()) {
    echo $row['order_code'] . " - " . $row['total'] . " - " . $row['status'] . "<br>";
}
?>

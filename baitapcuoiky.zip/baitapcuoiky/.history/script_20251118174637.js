// Smooth scrolling for anchor links
document.querySelectorAll('a[href="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Product hover animations
const productCards = document.querySelectorAll('.product-card');
productCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-15px)';
    });
    card.addEventLisener('mouseleave', function(){
        this.style.transform = 'translateY(0)';
    });
});


// Hiển thị form khi nhấn Sign In
document.getElementById('sign-in-link').addEventListener('click', function() {
    document.getElementById('login-form').style.display = 'block';
});

// Đóng form khi nhấn Close
document.getElementById('close-login').addEventListener('click', function() {
    document.getElementById('login-form').style.display = 'none';
});

// Xử lý login
const loginForm = document.getElementById('loginForm');

loginForm.addEventListener('submit', function(e) {
    e.preventDefault(); // Ngăn reload trang

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if(email === "admin@coffee.com" && password === "123456"){
        // Chuyển tới trang admin
        window.location.href = "admin.html";
    } else {
        alert("Email hoặc mật khẩu không đúng!");
    }
});

const track = document.querySelector('.slider-track');
const prev = document.querySelector('.prev');
const next = document.querySelector('.next');

let position = 0;
const slideWidth = 270; // 250px + 20px gap

next.addEventListener('click', () => {
    position -= slideWidth;
    if (Math.abs(position) >= track.scrollWidth - track.clientWidth) {
        position = -(track.scrollWidth - track.clientWidth);
    }
    track.style.transform = `translateX(${position}px)`;
});

prev.addEventListener('click', () => {
    position += slideWidth;
    if (position > 0) position = 0;
    track.style.transform = `translateX(${position}px)`;
});

const openShopping  = document.querySelector('.shopping');
const closeShopping = document.querySelector('.closeShopping');
const list          = document.querySelector('.list');
const listCard      = document.querySelector('.listCard');
const body          = document.body;
const total         = document.querySelector('.total');
const quantity      = document.querySelector('.quantity');

openShopping.addEventListener('click', () => {
    body.classList.add('active');
    document.querySelector('.card').classList.add('active');
});

closeShopping.addEventListener('click', () => {
    body.classList.remove('active');
    document.querySelector('.card').classList.remove('active');
});

const products = [
    { id: 1, name: 'Cánh Gà Nướng Cay', image: '1.png', price: 160000 },
    { id: 2, name: 'Salad Cá Hồi Nướng', image: '2.png', price: 180000 },
    { id: 3, name: 'Pizza Margherita', image: '3.png', price: 220000 },
    { id: 4, name: 'Súp Bí Đỏ Phô Mai', image: '4.png', price: 75000 },
    { id: 5, name: 'Salad Rau Tươi', image: '5.png', price: 90000 },
    { id: 6, name: 'Thịt Heo Nướng BBQ', image: '6.png', price: 250000 }
];

let listCards = [];

// Load sản phẩm ra trang
function initApp() {
    products.forEach((p, idx) => {
        const div = document.createElement('div');
        div.className = 'item';
        div.innerHTML = `
            <img src="image/${p.image}" alt="${p.name}">
            <div class="title">${p.name}</div>
            <div class="price">${p.price.toLocaleString()} ₫</div>
            <button onclick="addToCard(${idx})">Thêm vào giỏ</button>
        `;
        list.appendChild(div);
    });
}
initApp();

// Thêm hàng vào giỏ
function addToCard(idx) {
    if (!listCards[idx]) {
        listCards[idx] = { ...products[idx], quantity: 1 };
    } else {
        listCards[idx].quantity++;
    }
    reloadCard();
}

// Render giỏ hàng
function reloadCard() {
    listCard.innerHTML = '';
    let totalPrice = 0;
    let count = 0;

    listCards.forEach((item, idx) => {
        if (!item) return;

        totalPrice += item.price * item.quantity;
        count += item.quantity;

        const li = document.createElement('li');
        li.innerHTML = `
            <div><img src="image/${item.image}" alt=""></div>
            <div>${item.name}</div>
            <div>${(item.price * item.quantity).toLocaleString()} ₫</div>

            <div class="buttons">
                <button onclick="changeQuantity(${idx}, ${item.quantity - 1})">-</button>
                <div class="count">${item.quantity}</div>
                <button onclick="changeQuantity(${idx}, ${item.quantity + 1})">+</button>
            </div>
        `;
        listCard.appendChild(li);
    });

    total.innerText = totalPrice.toLocaleString() + ' ₫';
    quantity.innerText = count;
}

// Tăng / giảm số lượng
function changeQuantity(idx, newQty) {
    if (newQty <= 0) {
        delete listCards[idx];
    } else {
        listCards[idx].quantity = newQty;
    }
    reloadCard();
}

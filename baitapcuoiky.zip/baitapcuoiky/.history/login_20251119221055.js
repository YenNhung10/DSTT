// Giả lập tài khoản user (bạn có thể mở rộng hoặc dùng database thật)
const users = [
  { username: "admin", password: "123456" },
  { username: "user", password: "abc123" }
];

function login() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;

  const errorDiv = document.getElementById("error");
  errorDiv.textContent = "";

  if (!username || !password) {
    errorDiv.textContent = "Vui lòng điền đầy đủ thông tin!";
    return;
  }

  const user = users.find(u => u.username === username && u.password === password);
  if (user) {
    // Lưu trạng thái đăng nhập vào localStorage
    localStorage.setItem("loggedInUser", username);
    alert("Đăng nhập thành công!");
    window.location.href = "checkout.html"; // chuyển về trang chính
  } else {
    errorDiv.textContent = "Tên đăng nhập hoặc mật khẩu sai!";
  }
}
let user = JSON.parse(localStorage.getItem("user"));
let userInfo = document.getElementById("user-info");

if(user){
    userInfo.innerHTML = `Xin chào, ${user.name} <button onclick="logout()">Đăng xuất</button>`;
} else {
    userInfo.innerHTML = `<a href="signup.html" class="btn btn-secondary">SignUp</a>
                          <a href="login.html" class="btn btn-secondary">LogIn</a>`;
}

function logout(){
    localStorage.removeItem("user");
    location.reload(); // refresh để hiện lại SignUp/LogIn
}

// Giả lập tài khoản user (bạn có thể mở rộng hoặc dùng database thật)
const users = [
  { username: "admin", password: "123456" },
  { username: "user", password: "abc123" }
];

function login() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;

  const errorDiv = document.getElementById("error");
  errorDiv.textContent = "";

  if (!username || !password) {
    errorDiv.textContent = "Vui lòng điền đầy đủ thông tin!";
    return;
  }

  const user = users.find(u => u.username === username && u.password === password);
  if (user) {
    // Lưu trạng thái đăng nhập vào localStorage
    localStorage.setItem("loggedInUser", username);
    alert("Đăng nhập thành công!");
    window.location.href = "coffe.html"; // chuyển về trang chính
  } else {
    errorDiv.textContent = "Tên đăng nhập hoặc mật khẩu sai!";
  }
}

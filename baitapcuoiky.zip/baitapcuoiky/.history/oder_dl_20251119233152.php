<?php
$cn = new mysqli("localhost", "root", "", "coffeeshop");

if ($cn->connect_error) {
    die("Lỗi kết nối database: " . $cn->connect_error);
}

$order_id = $_GET["id"]; // lấy id từ URL

// Lấy thông tin đơn hàng
$order = $cn->query("SELECT * FROM orders WHERE id = $order_id")->fetch_assoc();

echo "<h2>Chi tiết đơn hàng</h2>";
echo "Mã đơn: " . $order['ma'] . "<br>";
echo "Ngày: " . $order['date'] . "<br>";
echo "Trạng thái: " . $order['status'] . "<br>";
echo "Tổng tiền: " . $order['total'] . " VND<br><br>";

// Lấy danh sách sản phẩm thuộc đơn này
$result = $cn->query("SELECT * FROM order_items WHERE order_id = $order_id");

echo "<h3>Sản phẩm</h3>";

while ($row = $result->fetch_assoc()) {
    echo "- " . $row['item_name'] . " (x" . $row['qty'] . ")<br>";
}
?>

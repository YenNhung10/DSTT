<?php
$result = $cn->query("SELECT * FROM orders");
while ($row = $result->fetch_assoc()) {
    echo $row['order_code'] . " - " . $row['total'] . " VND - " . $row['status'];
    echo " <a href='order_detail.php?id=" . $row['id'] . "'>Xem chi tiết</a><br>";
}
?>
